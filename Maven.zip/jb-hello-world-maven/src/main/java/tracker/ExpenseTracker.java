package tracker;

import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.time.YearMonth;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class ExpenseTracker {
    private List<Transaction> transactions = new ArrayList<>();
    private Scanner scanner = new Scanner(System.in);
    private DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");

    public static void main(String[] args) {
        ExpenseTracker tracker = new ExpenseTracker();
        tracker.menu();
    }

    private void menu() {
        while (true) {
            System.out.println("\n=== Expense Tracker ===");
            System.out.println();
            System.out.println("1. Add Transaction");
            System.out.println("2. View Monthly Summary");
            System.out.println("3. Load Transactions from File");
            System.out.println("4. Save Transactions to File");
            System.out.println("5. Exit");
            System.out.println();
            System.out.print("Choose an option: ");

            String input = scanner.nextLine();

            switch (input) {
                case "1":
                    addTransaction();
                    break;
                case "2":
                    viewMonthlySummary();
                    break;
                case "3":
                    loadFromFile();
                    break;
                case "4":
                    saveToFile();
                    break;
                case "5":
                    System.out.println("Exiting... Goodbye!");
                    return;
                default:
                    System.out.println("Invalid option. Try again.");
            }
        }
    }

    private void addTransaction() {
        System.out.print("Enter type (Income/Expense): ");
        String typeStr = scanner.nextLine().trim().toUpperCase();
        Transaction.Type type;

        try {
            type = Transaction.Type.valueOf(typeStr);
        } catch (IllegalArgumentException e) {
            System.out.println("Invalid type.");
            return;
        }

        String category;
        if (type == Transaction.Type.INCOME) {
            System.out.print("Enter category (Salary/Business): ");
        } else {
            System.out.print("Enter category (Food/Rent/Travel): ");
        }
        category = scanner.nextLine();

        System.out.print("Enter amount: ");
        double amount;
        try {
            amount = Double.parseDouble(scanner.nextLine());
        } catch (NumberFormatException e) {
            System.out.println("Invalid amount.");
            return;
        }

        System.out.print("Enter date (yyyy-MM-dd): ");
        String dateStr = scanner.nextLine();
        LocalDate date;
        try {
            date = LocalDate.parse(dateStr, dateFormatter);
        } catch (Exception e) {
            System.out.println("Invalid date format.");
            return;
        }

        transactions.add(new Transaction(type, category, amount, date));
        System.out.println("Transaction added!");
    }

    private void viewMonthlySummary() {
        System.out.print("Enter month (yyyy-MM): ");
        String input = scanner.nextLine();

        YearMonth month;
        try {
            month = YearMonth.parse(input);
        } catch (Exception e) {
            System.out.println("Invalid format.");
            return;
        }

        double incomeTotal = 0;
        double expenseTotal = 0;

        System.out.println("\nTransactions for " + month + ":");
        for (Transaction t : transactions) {
            if (YearMonth.from(t.date).equals(month)) {
                System.out.println(t);
                if (t.type == Transaction.Type.INCOME) {
                    incomeTotal += t.amount;
                } else {
                    expenseTotal += t.amount;
                }
            }
        }

        System.out.println("Total Income: " + incomeTotal);
        System.out.println("Total Expenses: " + expenseTotal);
        System.out.println("Net Savings: " + (incomeTotal - expenseTotal));
    }

    private void loadFromFile() {
        System.out.print("Enter file path to load: ");
        String path = scanner.nextLine();

        try {
            List<String> lines = Files.readAllLines(Paths.get(path));
            for (String line : lines) {
                String[] parts = line.split(",");
                if (parts.length != 4) continue;

                Transaction.Type type = Transaction.Type.valueOf(parts[0].trim().toUpperCase());
                String category = parts[1].trim();
                double amount = Double.parseDouble(parts[2].trim());
                LocalDate date = LocalDate.parse(parts[3].trim(), dateFormatter);

                transactions.add(new Transaction(type, category, amount, date));
            }
            System.out.println("Transactions loaded.");
        } catch (IOException | IllegalArgumentException e) {
            System.out.println("Failed to load file: " + e.getMessage());
        }
    }

    private void saveToFile() {
        System.out.print("Enter file path to save: ");
        String path = scanner.nextLine();

        try (PrintWriter writer = new PrintWriter(path)) {
            for (Transaction t : transactions) {
                writer.println(t);
            }
            System.out.println("Transactions saved.");
        } catch (IOException e) {
            System.out.println("Failed to save file: " + e.getMessage());
        }
    }
}